#!/bin/sh
#
# penemo uninstall script, must be run as root.
#

if [ $UID != 0 ]; then
	echo 'This script must be run as ROOT!';
	exit;
fi

echo 'uninstalling penemo...'
umask 002

echo 'removing /usr/local/etc/penemo/'
rm -rf /usr/local/etc/penemo
echo 'removing /usr/local/sbin/penemo'
rm /usr/local/sbin/penemo
echo 'removing /usr/local/share/penemo/'
rm -rf /usr/local/share/penemo

echo 'penemo has been removed from the system.'

