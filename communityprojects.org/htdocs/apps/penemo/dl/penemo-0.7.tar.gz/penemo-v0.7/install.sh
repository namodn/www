#!/bin/sh
#
# penemo install script, must be run as root.
#

if [ $UID != 0 ]; then
	echo 'This script must be run as ROOT!';
	exit;
fi

echo 'installing penemo...'

umask 002

if test -d /usr/local/etc; then
	echo 'creating /usr/local/etc/penemo/'
	mkdir /usr/local/etc/penemo
else
	echo 'creating /usr/local/etc/'
	mkdir /usr/local/etc
	echo 'creating /usr/local/etc/penemo/'
	mkdir /usr/local/etc/penemo
fi

echo 'copying configuration files to /usr/local/etc/penemo/'
cp conf/*.conf /usr/local/etc/penemo

echo 'copying penemo executable to /usr/local/sbin/'
cp penemo /usr/local/sbin/
chmod u=rwx,g=rwx,o= /usr/local/sbin/penemo

if test -d /usr/local/share; then
	echo 'creating /usr/local/share/penemo/'
	mkdir /usr/local/share/penemo
else
	echo 'creating /usr/local/share/'
	mkdir /usr/local/share
	echo 'creating /usr/local/share/penemo/'
	mkdir /usr/local/share/penemo
fi

echo 'creating /usr/local/share/penemo/cache/'
mkdir /usr/local/share/penemo/cache
echo 'creating /usr/local/share/penemo/html/'
mkdir /usr/local/share/penemo/html
echo 'creating /usr/local/share/penemo/html/agentdump/'
mkdir /usr/local/share/penemo/html/agentdump
echo 'creating /usr/local/share/penemo/html/agents/'
mkdir /usr/local/share/penemo/html/agents

echo 'finished installing penemo.'






